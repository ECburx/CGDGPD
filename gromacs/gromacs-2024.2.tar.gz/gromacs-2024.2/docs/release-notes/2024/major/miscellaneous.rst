Miscellaneous
^^^^^^^^^^^^^

.. Note to developers!
   Please use """"""" to underline the individual entries for fixed issues in the subfolders,
   otherwise the formatting on the webpage is messed up.
   Also, please use the syntax :issue:`number` to reference issues on GitLab, without
   a space between the colon and number!

Changed default value of tau-p to 5 ps
""""""""""""""""""""""""""""""""""""""

The new default value for the pressure coupling time of 5 ps
is larger than tau-t, as is recommended, and should work well
for most simulations.
